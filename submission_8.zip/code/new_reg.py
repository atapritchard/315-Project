import numpy as np
from os.path import join
from os import listdir
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from vectorizer import vectorize, get_word_bag
from tqdm import tqdm as tqdm

BAG_SIZE = 2000
dtype = np.float32
word_bag = get_word_bag()
mypath = "../new_dat"
pos_reviews = [f for f in listdir(join(mypath,"positive"))]
neg_reviews = [f for f in listdir(join(mypath,"negative"))]

##get data
x = np.zeros((len(pos_reviews) + len(neg_reviews), BAG_SIZE), dtype=dtype)
for i in tqdm(range(len(pos_reviews)), desc='+', ncols=80):
    x[i] = vectorize(join(mypath,"positive",pos_reviews[i]), word_bag)
    print(pos_reviews[i])
for j in tqdm(range(len(neg_reviews)), desc='-', ncols=80):
    x[len(pos_reviews) + j] = vectorize(join(mypath,"negative",neg_reviews[j]), word_bag)

y = [1]*len(pos_reviews) + [0]*len(neg_reviews)
#X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=1)


reg = LogisticRegression(C = .001)
reg.fit(x, y)
# labs = reg.predict(X_test)
# print("accuracy of LR: %i", (sum(np.equal(labs, y_test))/len(y_test)))

path = "../new_dat/test"
reviews = [f for f in listdir(path)]
test = np.zeros((len(reviews), BAG_SIZE), dtype=dtype)
for i in range(len(reviews)):
    test[i] = vectorize(join(path,reviews[i]), word_bag)

preds = reg.predict(test)
with open('task1_predictions.txt', 'w') as file:
    for line in preds:
        file.write(str(int(line)) + '\n')
print('Predict job completed.')